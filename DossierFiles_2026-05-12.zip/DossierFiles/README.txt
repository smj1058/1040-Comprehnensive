=== Accruity Client Intelligence Dossiers ===
Generated: 2026-05-12
Clients: 42

HOW TO USE:
- Drag this entire DossierFiles folder into your OneDrive at:
  C:\Users\SethJohnson\OneDrive - Subledge\_Client Review\Dossier Files
- OneDrive will sync to the cloud automatically.
- Share the folder from OneDrive web → grant Accruity team permissions.
- Open any dossier.html file in a browser to read the rendered dossier.

FOLDER STRUCTURE:
DossierFiles/
  PROJECT_OVERVIEW.md    ← project-level documentation
  HANDOFF_2026-04-22.md  ← run summary
  BATCH_REFRESH_PROMPT.md← per-client refresh contract
  <ClientName>/
    dossier.html         ← rendered, team-readable dossier (PRIMARY)
    dossier.md           ← markdown source (archival)

CLIENTS INCLUDED (42):
AidanMcIsaac
AlexDykesMarkFerguson
AndyKarabinos
AnnMarieGeddessFrankFelice
BeckyMead
BradKanouse
BrettZanotto
BrittanyByma
DanHamilton
DanielHuffman
DavidMichelleSaward
DonFowler
EvanMeganAugustine
GaryAronov
GianCarloLies
GilRamos
GregSmith
GregWhitmire
JahniStasil
JenniferStickler
JeremyLee
JeremyMartin
JoelCabrera
KaraHinshaw
KelliSalter
LaceyBlackman
LoganBowles
MattAndChelseaIannaccio
MichaelVenereo
MichelleBowles
MikeLucas
MonicaHayes
NickDenillo
ReneeMuellerJeffCohn
ReneeMuellerSolo
RussellFaucette
SandeePayne
SeanKennedy
SpringBengtzen
TanyaToliver
TateCline
TommyHarr

# Tommy Harr — Client Intelligence Dossier
**Internal Working Document — Accruity**

| Item | Detail |
| --- | --- |
| Client | Tommy Harr (Real Side Real Estate / Legacy Ohio Homes) |
| Client # | — (not yet assigned in Account record) |
| Mango Client ID | — (blank) |
| Prepared by | Accruity Tax Advisory |
| Date | 2026-04-22 |
| Prior Refresh | first run |
| Planning Year(s) | 2023 (amendment), 2025 (current), 2026 (forward) |
| Engagement Stage | Tax Ascend — Compliance + Amendment + Cost Seg + S-Corp restructure (active multi-track) |
| Temperature | Active & engaged · **HIGH urgency** (April 15 extension cycle, $196K live IRS balance, $110K amendment savings at stake) |
| Relationship Manager | Seth Johnson (CC'd on threads); Deontae Lafayette (Tax Compliance, primary thread owner) |
| Primary Contact | Tommy Harr — `tom@legacyohiohomes.com` · `realsiderealestate@gmail.com` · (614) 406-0997 |
| Secondary Contact | Sami Bates — `sami@legacyohiohomes.com` (CC'd on April 14 thread; likely spouse/operations) |
| Partner | Andy Karabinos — 50/50 across the operating entity stack |
| Data Sources (this refresh) | Notion Accounts record · 1 Email Log row (April 15 extension thread, 5 messages) · 13 Cost Seg Proposal rows · 1 Exec Summary DB row (shell) |
| Files NOT Accessible This Refresh | PBC Workbook (URL empty), Tax Extraction (empty), Tax Analysis Workbook, Tax Planning Memo, Meeting Prep Notes — all empty on Account record. Flagged for §5 Document Inventory. |

**Confidence:** ✓ Confirmed · ~ Estimated · ? Pending
**Attribution:** every non-obvious fact carries an inline source tag. See §12 Provenance Index at the end.

---

<!-- Sections appended one per turn. -->

---

## §1. Executive Overview

Tommy Harr (`tom@legacyohiohomes.com` · `realsiderealestate@gmail.com` · `(614) 406-0997`) is a **multi-entity real-estate operator** running a 50/50 partnership stack with **Andy Karabinos** across at least four entities: **Legacy Ohio Homes** (active operating partnership · 2025 K-1 income $312K Tommy's 50%), **COGS ULTD** (active operating partnership · 2025 K-1 $260K Tommy's 50%), **LHI** (rental portfolio · 2025 50% rental losses of **$922K** driven by **$1.5M mortgage interest**), and **B&M Management** (loss-of-record entity · $71K loss Tommy's 50%). `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]`

**What matters right now — April 15 cycle is HIGH urgency.** Tommy's 2025 estimated AGI is **negative** (LHI rental losses fully offset the $572K active K-1 income), so income tax is `$0`, but **SE tax of ~$35K** still applies on the active business income. Only `$6,480` in W-2 withholding has been collected; **no estimated payments were made**. Estimated **balance due at extension: $28,520**. Tommy proposed paying `$6,000` and asked Accruity to confirm; Deontae offered to process the extension payment via online portal or Tommy-supplied bank info. **As of 2026-04-14, Accruity is awaiting Tommy's bank information to file the extension before April 15.** `[EI:Re: April 15 - Extension & 2025 Tax Status §Synopsis]` `[Email 2026-04-14 Tom→Deontae]`

**Layered above the extension cycle, four distinct tax-engagement tracks are simultaneously active:**

1. **IRS payment plan & balance management** — $196K live IRS balance ($141K from 2023 + $55K accruing on 2025) on a `$12,000/month` payment plan. The 2025 balance-due ($28,520) compounds against the existing balance unless paid with the extension. `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]`
2. **Prior-year amendment ($110K combined savings)** — Accruity is preparing amendments expected to deliver `$65K Tommy + $45K Andy` in combined savings, **including resolution of a $23K AMT issue** carried in from a prior year. Post-4/15 work. `[EI:Re: April 15 - Extension & 2025 Tax Status §Action Items]`
3. **$400K office depreciation reclass** — separate post-4/15 deliverable; basis adjustment / improvement classification likely. `[EI:Re: April 15 - Extension & 2025 Tax Status §Action Items]`
4. **S-Corp restructure pipeline** — flagged in email-thread action list as future work; entity-by-entity scope and timing not yet committed. `[EI:Re: April 15 - Extension & 2025 Tax Status §Action Items]`

**Cost segregation track is exceptionally active.** Tommy has **13 Cost Seg Proposal rows** on his Account — far more than any other client encountered this refresh. These represent properties under evaluation in the LHI rental portfolio (or one of the operating entities); each will need to be reconciled against §5.4 PBC property-schedule once the workbook is linked. `[Accounts:Tommy Harr.Cost Seg Proposals]` The cost-seg pipeline is also explicitly listed as a post-4/15 deliverable. `[EI:Re: April 15 - Extension & 2025 Tax Status §Action Items]`

**Coverage model.** Deontae Lafayette (Tax Compliance) owns the active extension-and-payment thread. Sophia Leonardo (Tax Admin) is the portal/admin contact. Seth Johnson (Relationship Manager) and Stacy Cvengros are CC'd. Sami Bates (`sami@legacyohiohomes.com`) is also CC'd — likely Tommy's spouse or operations partner — and `tax@accruity.com` is on the CC list as the team-inbox. `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]`

**Current refresh gaps.** No PBC Workbook, Tax Extraction, Tax Analysis Workbook, Tax Planning Memo, or Meeting Prep Notes URLs are linked on the Account record, so the entity stack, full property schedule, prior-year baseline, and projected savings narrative cannot be reconciled at this pass. They are flagged for §5 Document Inventory and will populate automatically on the next refresh once the Account is linked. `[Accounts:Tommy Harr]`

---

## §2. Client Profile

| Item | Value | Confidence | Source |
| --- | --- | --- | --- |
| Filing status | Likely MFJ (Sami Bates CC'd, possibly spouse) — `? Pending confirmation` | ~ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]` |
| Residency | Ohio (Legacy Ohio Homes operates statewide; Real Side Real Estate brokerage) | ~ | derived |
| Client # | — (blank on Account record) | ❌ | `[Accounts:Tommy Harr.Client #]` |
| Mango Client ID | — (blank on Account record) | ❌ | `[Accounts:Tommy Harr.Mango Client ID]` |
| Mango Display Name | Tommy Harr | ✓ | `[Accounts:Tommy Harr.Mango Display Name]` |
| Primary Contact | Tommy Harr — `tom@legacyohiohomes.com` (operating); `realsiderealestate@gmail.com` (brokerage); `(614) 406-0997` | ✓ | `[Accounts:Tommy Harr]` |
| Secondary Contact / Operations | Sami Bates — `sami@legacyohiohomes.com` | ~ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]` |
| Business partner (50/50) | Andy Karabinos — across Legacy Ohio Homes, COGS ULTD, LHI, B&M Management | ✓ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Points]` |
| Relationship Manager | Seth Johnson | ✓ | `[Accounts:Tommy Harr]` |
| Active thread owner | Deontae Lafayette (Tax Compliance) | ✓ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]` |
| Engagement Stage | Tax Ascend — Compliance + Amendment + Cost Seg + S-Corp restructure (active multi-track) | ✓ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Action Items]` `[Accounts:Tommy Harr.Cost Seg Proposals]` |
| Temperature | Active & engaged · **HIGH urgency** ($28,520 due Apr 15, $196K IRS balance, $12K/mo payment plan) | ✓ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Flags]` |
| Cost Seg pipeline | **13 Cost Seg Proposal rows on file** — exceptionally active for one client | ✓ | `[Accounts:Tommy Harr.Cost Seg Proposals]` |
| Engagement letters on file | None linked to Account record (gap to backfill) | ❌ | `[Accounts:Tommy Harr.Engagement Letters]` |
| IRS posture | $196K total balance ($141K 2023 + $55K 2025) on $12K/month payment plan | ✓ | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]` |

### Principals at a glance

- **Tommy Harr** — Operator/principal across the Legacy Ohio Homes / COGS ULTD / LHI / B&M Management stack. Real-estate brokerage (Real Side Real Estate) on the side. W-2 income reported `$48,000` (2025 thread) — likely a structured wage from one of the operating entities or a brokerage role. `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]`
- **Andy Karabinos** — 50/50 partner across the operating-entity stack. Currently flagged as a **separate Account** in the missing-rows list at `docs/BATCH_REFRESH_PROMPT.md` — meaning Andy will get his own dossier eventually, and the dossiers should cross-reference each other. `[CLAUDE.md §Remaining client queue]`

### Entity stack (provisional — reconcile with PBC on next refresh)

`[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]`

| Entity | Federal Form (estimated) | 2025 Income/Loss (Tommy 50%) | Status this refresh | Source |
| --- | --- | --- | --- | --- |
| **Legacy Ohio Homes** | 1065 partnership (K-1 of $312K Tommy 50% of $624,943) | +$312,472 | Active operating | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]` |
| **COGS ULTD** | 1065 partnership (K-1 of $260K Tommy 50% of $520,356) | +$260,178 | Active operating | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]` |
| **LHI** *(Legacy Holdings/Investments? — to confirm naming)* | 1065 partnership (rental portfolio) | -$922,000 (50% nonpassive losses from $1.5M mortgage interest) | Active rental holding | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]` |
| **B&M Management** | 1065 partnership | -$71,000 (50% loss) | Active loss-of-record | `[EI:Re: April 15 - Extension & 2025 Tax Status §Key Numbers]` |
| **Real Side Real Estate** | Brokerage entity (TBD — possibly W-2 employer, possibly LLC) | $48,000 W-2 likely sourced here | Active brokerage | derived from contact email `realsiderealestate@gmail.com` |

The four K-1 entities net to roughly `$312K + $260K - $922K - $71K = -$421K` on Tommy's side (active K-1 income offset by LHI rental losses), driving negative AGI for 2025. `[EI:Re: April 15 - Extension & 2025 Tax Status §Synopsis]`

### Third parties in the file

| Party | Role | Status / Notes |
| --- | --- | --- |
| Sami Bates — `sami@legacyohiohomes.com` | CC'd on extension thread; same domain as Tommy | Likely spouse / operations principal `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]` |
| Andy Karabinos | 50/50 partner across the operating stack | Separate Accruity client — own Account row pending creation `[CLAUDE.md §Remaining queue]` |
| `tax@accruity.com` | Team inbox CC'd on extension thread | Standard team-inbox routing `[EI:Re: April 15 - Extension & 2025 Tax Status §Participants]` |

---

## §3. Email Intelligence

**Scope of this refresh:** 1 email thread on the Account (Notion Client Email Log). HIGH risk · ACTIVE · 5 messages over 5 days · time-critical (April 15 extension cycle). No noise threads found this refresh. Append-only on subsequent refreshes. `[Accounts:Tommy Harr.Email Log]`

**Rollup:** 1 active multi-party HIGH-risk thread, 8 open action items, $28,520 + $196K + $110K + $400K + $35K + $23K of distinct dollar exposure quantified inside the thread. Broader Outlook scan for `tom@legacyohiohomes.com` / `realsiderealestate@gmail.com` / `sami@legacyohiohomes.com` over the last 18 months is **flagged pending** — generator's email reader will backfill on next refresh. `[Gap: Outlook live scan deferred]`

### 3.1 Active Threads

---

#### 🔴 **Re: April 15 - Extension & 2025 Tax Status** · HIGH risk · ACTIVE
**Conversation ID:** `AAMkADBmZjg2NGQ4…AAQ8ogn2AAA=` · **Source inbox:** `seth@accruity.com` · **Messages:** 5 · **Date range:** 2026-04-09 → 2026-04-14 · **Direction:** Outbound-initiated (Accruity → Tommy) · **Outlook:** [Open in Outlook](https://outlook.office365.com/owa/?ItemID=AAMkADBmZjg2NGQ4LTFhNTgtNGI2Mi05MmJmLTlhMWZkNDVkMjVkZQBGAAAAAAAY75o7uPA2RpuX8UEo5dXBBwBwW9uyQOvRTKnXOw4wkwFeAAAAAAEMAABwW9uyQOvRTKnXOw4wkwFeAAQ8ogn2AAA%3D&exvsurl=1&viewmodel=ReadMessageItem) `[Email 2026-04-09 Accruity→Tom "April 15 - Extension"]`

**Participants:**
- **Tom Harr** (`tom@legacyohiohomes.com`) — Client (initiator of replies)
- **Deontae Lafayette** (`deontae.lafayette@accruity.com`) — Accruity Tax Compliance (active thread owner)
- **Sophia Leonardo** (`sophia@accruity.com`) — Accruity Tax Admin
- **Seth Johnson** (`seth@accruity.com`) — Relationship Manager (CC'd)
- **Stacy Cvengros** (`stacy@accruity.com`) — Accruity (CC'd)
- **Samantha Bates / Sami** (`sami@legacyohiohomes.com`) — Tommy-side ops (CC'd)
- `tax@accruity.com` — team inbox (CC'd)

**Synopsis.** On **April 9, 2026**, Accruity sent Tom a detailed 2025 income estimate showing **negative AGI** driven by `$922K` in LHI rental losses (driven by `$1.5M` mortgage interest on the LHI portfolio) which fully offset active business income from COGS ULTD (`$260K` at 50%) and Legacy Ohio Homes (`$312K` at 50%). **Income tax: `$0`. SE tax: `$35K`** (rental losses don't reduce SE income; SE applies to active K-1 earnings). Only `$6,480` in W-2 withholding confirmed; no estimated payments were made. Estimated balance due: **`$28,520`**. `[Email 2026-04-09 Accruity→Tom "April 15 - Extension"]`

On **April 10**, Tom confirmed no payments were made, said he wants to pay with the extension, and asked that the **`$23K` AMT issue from a prior year** be addressed in the amendment work. `[Email 2026-04-10 Tom→Accruity]`

On **April 14**, Tom asked what Accruity needed from him. **Deontae** explained the payment options: (a) Tom pays online via the IRS Direct Pay portal, or (b) Tom provides bank info to Accruity, who will process the extension payment when the extension is filed. Tom asked if `$6,000` was a recommended payment, and offered his bank info. `[Email 2026-04-14 Deontae→Tom]` `[Email 2026-04-14 Tom→Deontae]`

**Separately tracked in this thread (post-4/15 deliverables):**
- IRS balance management: **`$196K`** total (`$141K` for 2023 + `$55K` accruing on 2025) on a **`$12,000/month` payment plan** — adding the `$28,520` extension balance compounds against this unless paid with the extension. `[EI §Key Numbers]`
- **Amendment work**: `$110K` combined savings (`$65K` Tommy + `$45K` Andy), including resolution of the `$23K` AMT issue. `[EI §Key Numbers]`
- **Office depreciation reclass**: `$400K` basis adjustment — separate post-4/15 deliverable. `[EI §Key Numbers]`
- **Cost seg study** (post-4/15) — connects to the 13 Cost Seg Proposal rows on Account. `[Accounts:Tommy Harr.Cost Seg Proposals]`
- **S-corp restructure** (pipeline) — entity-by-entity scope and timing not yet committed. `[EI §Action Items]`

**Key numbers anchored in this thread (full inventory):**
- W-2 wages: `$48,000` · COGS ULTD K-1 (50% of $520,356): `$260,178` · Legacy Ohio Homes K-1 (50% of $624,943): `$312,472` · LHI rental losses (50%, nonpassive): `($922,000)` · B&M Management loss (50%): `($71,000)` · Estimated AGI: **Negative** · Income tax: `$0` · SE tax (on $572K active SE earnings): `$35,000` · W-2 withholding: `$6,480` · Estimated payments: `$0` · Balance due: **`$28,520`** · Safe harbor (100% PY tax): `$52,981` · IRS balance: **`$196,000`** (`$141K` 2023 + `$55K` 2025) · Payment plan: `$12,000/month` · Amendment savings: **`$110,000` combined** (`$65K` Tommy + `$45K` Andy) · Office dep reclass: `$400,000` · AMT issue: `$23,000` · Mortgage interest (LHI portfolio): `$1,500,000` · Tom mentioned: `$6,000` proposed payment. `[EI §Key Numbers]`

**Action items generated by this thread** *(owner · status — promoted to §7 Action Items on Turn 7):*
- Tommy — Provide bank info for extension payment (URGENT — pre Apr 15) — In Progress
- Deontae — Process extension payment with Tommy's bank info before deadline — In Progress
- Accruity (Deontae) — File extension before April 15 — Open
- Accruity — Address `$23K` AMT issue in prior-year amendment — Open (post-4/15)
- Accruity — Complete cost seg study (post-4/15) — Open
- Accruity — Process amendments (`$110K` combined savings — `$65K` Tommy + `$45K` Andy) — Open (post-4/15)
- Accruity — Office dep reclass (`$400K`) post-4/15 — Open
- Accruity — S-Corp restructure (pipeline) — Open

**Risk flags:** HIGH (Money). `$28,520` extension balance + `$196K` IRS balance + `$110K` amendment savings + `$400K` office reclass at stake. Apr 15 deadline is the immediate gate; amendment + cost-seg + S-corp work follows. `[EI §Flags]`

### 3.2 Noise Threads (Filtered)

None this refresh.

### 3.3 Thread Rollup

| Metric | Value | Source |
| --- | --- | --- |
| Substantive threads this refresh | 1 | `[Accounts:Tommy Harr.Email Log]` |
| Noise threads filtered | 0 | — |
| Open action items from email | 8 | `[EI §Action Items]` |
| Unique Accruity participants in flight | Deontae · Sophia · Seth · Stacy | `[EI §Participants]` |
| Most recent inbound | Tom — 2026-04-14 (offering bank info, asking $6,000 confirm) | `[Email 2026-04-14 Tom→Deontae]` |
| Most recent outbound | Deontae — 2026-04-14 (payment-options explanation) | `[Email 2026-04-14 Deontae→Tom]` |
| Days to extension deadline (as of refresh date) | -7 (deadline already passed at refresh date 2026-04-22 — confirm extension was filed with payment) | derived |
| Risk profile | HIGH — Money flag with $28,520 + $196K + $110K + $400K stakes | `[EI §Flags]` |

### 3.4 Gaps to backfill on next refresh

- **Live Outlook scan** for `tom@legacyohiohomes.com` / `realsiderealestate@gmail.com` / `sami@legacyohiohomes.com` / `legacyohiohomes.com` domain over the last 18 months. Substantial likelihood that engagement-letter, prior-year-return, IRS-notice, and cost-seg-onboarding threads exist that aren't yet in the Notion log.
- **Andy Karabinos parallel scan** — Andy is the 50/50 partner on the same entities and may have his own threads on the Accruity side that affect Tommy's positions.
- **Confirm extension filing happened on or before 2026-04-15** with payment processed — this thread ended 2026-04-14 still gathering bank info. Update status next refresh.
- **Make-scenario-captured threads** — confirm whether the user's Make scenarios that pipe accruity.com inboxes into the Client Email Log have run for tax@accruity.com / seth@accruity.com / sophia@accruity.com / deontae.lafayette@accruity.com / stacy@accruity.com on Tommy-mentioned threads. If yes, backfill those rows next refresh.

---

## §4. Meeting History

**Scope of this refresh:** 2 meetings on file in the Notion Meetings Tracker tied to Tommy Harr (one via Account relation, one matched by client-name string with no Account relation populated). Both unrestricted. Both have recap URLs. Append-only on subsequent refreshes. `[Accounts:Tommy Harr.Meetings — implied via search]`

> ⚠️ **Discovery flag — dual Account records suspected.** The 2026-02-11 "Tommy Harr and Andy K" meeting is linked to Account `30d49172875181ddb232f4b70fb47e04`, which is **different** from the Account record this dossier is anchored to (`3424917287518141812be02393d26cb1`). Two plausible explanations: (a) an older/duplicate Tommy Harr Account row exists in the Accounts DB and needs to be reconciled / merged, or (b) `30d49172…7e04` is actually Andy Karabinos's Account (since the meeting was joint Tommy + Andy). Promoted to §7 as a plumbing item — confirm next refresh by fetching the other Account page.

### 4.1 Chronological log (newest → oldest)

| Date | Type | Time (EST) | Status | Recap | Account linked? | Source |
| --- | --- | --- | --- | --- | --- | --- |
| **2026-02-25** | Tax Planning Session | 2:00 – 2:30 PM | Done ✓ | [Fellow recap](https://sg5.fellow.app/uni/ls/click?upn=u001.Y1tiWTgJ1PJMrKyj7dbJHqPp-2FT6JwyJKYnLKCSUh0dRKOQm2cj6PWWcYw1WzaV8IB9FGQODOjD0Q-2B5JJcCrN5BRAOPWH3ooUhVUuFVrRbbcKvq39JUo20X8G6-2FzaK8u5-2BDRYjdRd7ccspDaY-2FNEwPsx-2BmtvaUoNrHlT76DG3EqkdDJOMNCUTWrfeY09EhHMpTvlSLREAcGCle1z0EQ-2FFnRwhg1-2FIIS8C6IBMVFkyfWhp7w-2BxyknOlw5ZK9nOYxk-2BwdQ6jEFpyB12n1aRJb9B73fbr4Pslhn5u9-2F0IqpbmU2hH7460Ixy4IRd2HhvdT-2FsZnymnKd-2B3TOjpyQIY-2Bv3B9ZYyVDk-2BNFDDKvvlY8SE1kHJaB1jsWD5BgmRQsBDNIhKiuh5AY0sH1w9q8nCULikaIvB5knh5oCwFZdC-2BscOY8ipHN0-2FwCOGj4RFT2Jjx-2BwUX3yQboIRQ7cXM4dAv3G5FFVzHv030sU8jPsExpXJy4UajTekbmTk9ledqy7ZJA3RP-2BKm3C2LOCmHrdYgD-2BeOHVe9JOQqxhV4CiGyRhDS9oaMI9oRbZEYssGScwZEUcg44km_nCyD0OjfWWda0fny7BdXCaZa1dTuV49YyfNg3yJrg97FL3Kv0EHJMcicPdkuqwuRdzjRrm80tEQd1-2BziUVdt4N-2BENqkwrYnMwunCF16u8LRHLYXwliaO-2FRxCTdaxoscX0qRzlE7rIioEu87itWKBhA35b-2BLtpeZdY5FttszEKk98S-2BAkQjeAEezMXDnx4Erip9FzEXDDzYaOs5Vcm1AsYb-2BgpyoamtklMs0g2uty2jkLjDmv7S713h0dFNaejm6R4aacY7tM-2BP0Ba2zS1tS4g4lNk1ZUqKdUjExLsKx4IXKxbWGPcQL0vxW8Qyj2yn4a5ix4R0g2Yru3eRWmZLGhh84fwBeZSH3h12ETm6-2Fl4qe2Nre9VtgjSdgNHHF7M5rgOoyImZHHDfOL1RD170sXKpdh22SsY9Id4F65zZHdaDFbEcH-2BNR2-2FGFymfze07EF4) | ❌ no Account relation populated | `[Meeting 2026-02-25 Thomas Harr]` |
| **2026-02-11** | Tax Discussion | (no time set) | **Pending** ⚠️ | [MS Teams recap](https://teams.microsoft.com/l/meetingrecap?driveId=b%219Sy6PCqW-k-mi_pkBBdtAnmxOhkZ9z9DnB1ebRRhIxorE7g_sYChQIEPQYfrGcNH&driveItemId=01SRMA4TPXZP722266UJGZTF4BZETURQB5&sitePath=https%3A%2F%2Fsubledgesl-my.sharepoint.com%2F%3Av%3A%2Fg%2Fpersonal%2Fseth_accruity_com%2FIQD3y_-ta96iTZmXgcknSMA9AXSzRgHYIKk3QRNt8mCZuBQ&fileUrl=https%3A%2F%2Fsubledgesl-my.sharepoint.com%2Fpersonal%2Fseth_accruity_com%2FDocuments%2FRecordings%2FCall+with+Bryan+Szpindor-20260210_162550-Meeting+Recording.mp4%3Fweb%3D1&threadId=19%3Aa9669322-34d5-4d98-8e4e-a4e265a7d094_c10aa3b2-2b43-4013-834a-10a4dc624394%40unq.gbl.spaces&callId=00969c7a-612d-4a1f-a297-7d43f3fecab3&threadType=OneOnOneChat&meetingType=Unknown&subType=RecapSharingLink_RecapCore) | ✓ to `30d49172…7e04` (different Account!) | `[Meeting 2026-02-11 Tommy + Andy K]` |

### 4.2 Meeting-by-meeting detail

---

#### 🎙 **2026-02-25 · Tax Planning Session** · Done
**Title:** "Thomas Harr" · **Recap:** Fellow.app · **Status:** Done · **Restricted:** No · **Time:** 2:00–2:30 PM EST. `[Meeting 2026-02-25 Thomas Harr]`

This is the **most recent Tommy-side strategic session** on file, occurring ~6 weeks before the April 9 extension thread opened. Likely the session that produced the strategic framework now in flight: amendment work ($110K savings), $400K office dep reclass, S-corp restructure pipeline, and the cost-seg study tied to the 13 Cost Seg Proposal rows. The Fellow recap should be re-ingested on the next refresh to pull exact decisions and quotes into §10 Operations and §11 Individual Profile. `[Gap: Fellow transcript ingestion]`

**Account relation gap.** This row has **no Account relation populated** — it was matched to Tommy by the title string "Thomas Harr" via search, not via a structured relation. The relationship-manager workflow should set the Account relation so future queries scoped to `Account = Tommy Harr` include this meeting. Promoted to §7 as a plumbing item.

---

#### 🎙 **2026-02-11 · Tax Discussion** · **Pending ⚠️** · joint Tommy + Andy K
**Title:** "Tommy Harr and Andy K" · **Recap:** Microsoft Teams (Recording: "Call with Bryan Szpindor" 2026-02-10 16:25 EST) · **Status:** Pending · **Restricted:** No. `[Meeting 2026-02-11 Tommy + Andy K]`

This was a **joint Tommy + Andy** session, suggesting the partnership stack (Legacy Ohio Homes / COGS ULTD / LHI / B&M Management) was discussed jointly. The recording title references **Bryan Szpindor** — a new third-party participant not previously in this dossier's third-party orbit. Bryan's role is unclear from the row metadata; he could be an outside CPA, attorney, lender, or potential investor. **Pending** status means the Accruity-side meeting-tracker workflow has not closed this row out — needs a status update. `[Action:Meetings tracker cleanup]`

**Account relation issue.** This row's Account relation points to `30d49172875181ddb232f4b70fb47e04` — **not** the Tommy Harr Account record this dossier is anchored to (`3424917287518141812be02393d26cb1`). Two possibilities:
1. There is a **duplicate Tommy Harr Account** in the Accounts DB that needs reconciliation/merging.
2. `30d49172…7e04` is actually **Andy Karabinos's Account record**, since the meeting was joint Tommy + Andy.

Either way, this is a plumbing item: confirm next refresh by fetching `30d49172…7e04` and either merging the duplicate or updating the meeting row's Account relation to include both Tommy AND Andy. Promoted to §7 Action Items.

### 4.3 Meetings referenced elsewhere but NOT in the Meetings Tracker

The April 9 → April 14 extension thread does not reference any specific synchronous meeting. The thread implies a longer prior planning relationship (the amendment scope, $400K office dep reclass, S-corp restructure plan, and cost-seg pipeline all pre-date the thread), so additional planning sessions likely exist but aren't logged. Backfill on next refresh once the live Outlook scan + meeting-transcript MCP queries are run.

### 4.4 Rollup

| Metric | Value | Source |
| --- | --- | --- |
| Total meetings on file | 2 | search-matched |
| Status breakdown | 1 Done · 1 Pending ⚠️ | derived |
| Meeting cadence | 14 days between the two on file (2026-02-11 → 2026-02-25) | derived |
| Meeting types | 1 Tax Discussion · 1 Tax Planning Session | derived |
| Recap platforms | 1 Fellow · 1 MS Teams (with Bryan Szpindor) | derived |
| Transcripts ingested this refresh | 0 (URLs captured; full pull deferred to Granola/Fathom MCP) | `[Gap: transcript ingestion]` |
| Meetings with Restricted flag | 0 | `[Meetings Tracker.Restricted]` |
| Last meeting (any status) | 2026-02-25 Tax Planning Session | derived |
| Days since last meeting | 56 days (as of 2026-04-22 refresh) | derived |
| Meetings with Account relation populated | 1 of 2 (50% — plumbing gap) | derived |
| Meetings linked to wrong Account | 1 (the 02-11 Tommy + Andy K meeting points to `30d49172…7e04` instead of `34249172…2cb1`) | derived |

### 4.5 Gaps to backfill on next refresh

- **Resolve dual-Account question** — fetch page `30d49172875181ddb232f4b70fb47e04` and confirm whether it is (a) a duplicate Tommy Harr Account to merge or (b) Andy Karabinos's Account. Either way, fix the meeting-row's Account relation so it surfaces under Tommy.
- **Set Account relation on 2026-02-25 "Thomas Harr" meeting row** — currently empty; should point to `34249172…2cb1` so the Account → Meetings relation populates correctly.
- **Resolve Pending status on 2026-02-11 meeting** — close-out Done/Canceled with reason.
- **Pull Fellow transcript** for 2026-02-25 — extract the strategic framework discussed (amendment scope, dep reclass, S-corp plan, cost-seg pipeline) into §10 Operations.
- **Pull MS Teams recording** for 2026-02-10 (the "Call with Bryan Szpindor" referenced in the 02-11 meeting row) — clarify Bryan's role and whether he should be added to §3 third-party orbit.
- **Backfill any Tax Planning Session meeting prior to 2026-02-11** — the amendment/dep-reclass/S-corp scope discussed in the April thread implies earlier planning sessions; locate them next refresh.

---

## §5. Document Inventory

**Scope of this refresh:** 0 Engagement Letters · 0 Files & Links rows · 13 Cost Seg Proposal Intake rows (mostly empty placeholders — see §5.2) · 5 core tax workbooks unlinked on Account record. External document platforms in play: SharePoint (`seth@accruity.com` OneDrive — implied via meeting recap URL), MS Teams (recording for the Bryan Szpindor call), Fellow.app. `[Accounts:Tommy Harr]`

### 5.1 Engagement Letters

**None linked to Account record.** This is a meaningful gap given the engagement is HIGH-urgency (April 15 extension cycle + $196K IRS balance + active amendment + cost-seg + S-corp restructure tracks). Either:
- (a) Engagement letter exists on file but is not linked to the Account in the Engagement Letters Tracker DB, or
- (b) No formal EL has been signed yet and the engagement is operating informally.

Promoted to §7 Action Items as `Accruity ops — locate or originate Tommy Harr engagement letter`.

### 5.2 Cost Seg Proposal Intake rows — important nuance

Tommy's Account references **13 rows** in the Cost Seg Proposal Intake DB (`collection://741deb78-a449-408f-a388-8676d7b319bb`). On the surface this looks like an exceptionally active cost-seg pipeline — **but on inspection the rows are mostly empty placeholders.**

| Row | Title | Status | Property Address | Entity Name | Placed in Service | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| `3484…7344` (parent) | "Tommy Harr - Cost Seg" | **New - Enter in Portal** | (empty) | (empty) | (empty) | Parent row · 12 sub-items below |
| `3484…b0b` (sample child) | (untitled — "New page" / deleted) | New - Enter in Portal | (empty) | (empty) | (empty) | Sub-item; deleted-flag in Notion |
| 11 other sub-items | (sampled — same shape) | New - Enter in Portal | (empty) | (empty) | (empty) | Same shape, all empty |

**Read:** these 13 rows are an **intake-form skeleton** that was created (likely from a Make scenario or a portal-onboarding template) but **never filled in with actual property details**. Status = "New - Enter in Portal" on all. They represent **intent to run cost seg** on something between 1 and 13 properties — but the actual property addresses, basis, EINs, placed-in-service dates, and study fees are not yet captured.

**Implication for §8 / §9:** the §9.1 Cost Seg Candidates table cannot be populated from these rows this refresh — the data is empty. The "post-4/15 cost-seg study" referenced in the April email thread `[EI §Action Items]` is the work that will populate these intake rows; once filled, the §9 classifier will run normally.

Promoted to §7 Action Items as `Accruity / Tommy — populate the 13 Cost Seg Proposal Intake rows with actual property addresses, basis, and placed-in-service dates (post-4/15 deliverable referenced in the April extension thread)`.

### 5.3 External document platforms in play

| Platform | Purpose | Entry point(s) | Source |
| --- | --- | --- | --- |
| **MS Teams** | Recording of the 2026-02-10 "Call with Bryan Szpindor" referenced in the 02-11 meeting tracker row | [Teams meeting recap link](https://teams.microsoft.com/l/meetingrecap?…) | `[Meeting 2026-02-11 Tommy + Andy K]` |
| **Fellow.app** | Recap of the 2026-02-25 Tax Planning Session | [Fellow recap link](https://sg5.fellow.app/uni/ls/click?…) | `[Meeting 2026-02-25 Thomas Harr]` |
| **SharePoint (`seth@accruity.com` OneDrive)** | Implied — the MS Teams recording redirects to a SharePoint-hosted .mp4 file under `/personal/seth_accruity_com/Documents/Recordings/` | (URL inside the Teams recap link) | derived |
| **Cost Seg Portal** (TBD platform) | Where the 13 intake rows are intended to be entered (Status: "New - Enter in Portal") | — | `[Cost Seg Proposal status]` |

### 5.4 Files still missing (gap to backfill)

| File | Expected location | Account field | Status | Next-step |
| --- | --- | --- | --- | --- |
| **PBC Workbook** (xlsx) | Drive or SharePoint linked on Account.PBC Workbook | empty ❌ | Not linked | Locate + link next refresh — needed to reconcile the 4-entity stack and full property schedule |
| **Tax Extraction (Insights Delivery Workbook)** | Account.Tax Extraction URL | empty ❌ | Not linked | Locate + link next refresh — needed for prior-year baseline + the $48K W-2 source confirmation |
| **Tax Analysis Workbook** | Account.Tax Extraction (shared) or its own field | empty ❌ | Not linked | Locate + link next refresh — needed for the projected savings on $110K amendment + $400K dep reclass |
| **Tax Planning Memo** (.docx) | Account.Tax Planning Memo URL | empty ❌ | Not linked — but the 2026-02-25 Tax Planning Session likely produced one | Locate Feb 2026 planning memo deliverable + link next refresh |
| **Meeting Prep Notes** | Account.Meeting Prep Notes URL | empty ❌ | Not linked | Locate prep notes for 02-11 + 02-25 meetings + link next refresh |
| **Engagement Letter** | Engagement Letters Tracker DB row tied to Account | not in tracker ❌ | Not on file | Confirm whether EL exists; if so add tracker row; if not, originate |
| **Files & Links rows** | Files & Links DB rows tied to Account | 0 rows ❌ | None on file | Originate at least one Files & Links row to track Document Inventory + PBC PDF Package URLs as those get populated |

### 5.5 Rollup

| Metric | Value | Source |
| --- | --- | --- |
| Engagement Letters on file | **0** ⚠️ | `[Accounts:Tommy Harr.Engagement Letters]` |
| Files & Links rows | **0** ⚠️ | `[Accounts:Tommy Harr.Files & Links]` |
| Cost Seg Proposal Intake rows | 13 (mostly empty placeholders awaiting property data) | `[Accounts:Tommy Harr.Cost Seg Proposals]` |
| Cost Seg Engagements (executed studies) | 0 — none yet commissioned | `[Accounts:Tommy Harr]` |
| Core tax workbooks not linked to Account | 5 (PBC Workbook, Tax Extraction, Tax Analysis, Tax Memo, Meeting Prep) | `[Accounts:Tommy Harr]` |
| Document-platform footprint | MS Teams · Fellow · SharePoint (implied) · TBD Cost Seg Portal | derived |
| External document inventory completeness | LOW — most documents are not linked or are awaiting population | derived |

---

## §6. Claude Work Product

**Scope of this refresh:** Queried the Notion **Claude Summaries** database (`collection://86dca8a4…`) and the **Claude Activity Log** database (`collection://f9cc7d05…`) for sessions tied to Tommy Harr. **2 prior Claude sessions found**, both directly relevant. Neither is currently linked to Tommy's Account record via a structured relation — they were matched by name in the Summary text via search. `[Claude Summaries DB]` `[Claude Activity Log DB]`

### 6.1 Prior Claude sessions tied to this account

| Date | Thread Title | Topics | Tommy's role | Source |
| --- | --- | --- | --- | --- |
| **2026-04-08** | **Cost Seg Pipeline — Property Lists, File Inventory & Follow-Up Tracker** | Cost Seg pipeline triage across 8 clients | Direct subject (alongside Andy Karabinos) | [notion.so/33c49172875181098390e5d079955549](https://www.notion.so/33c49172875181098390e5d079955549) |
| **2026-04-08** | Aidan McIsaac Research + New Client Alert Review — 2026-04-08 | New Client Alert review (cross-client) | **Tommy is the referral source for Meghan Botkin** (4/3 new client, $2,500 Foundations+ / $500/mo retainer) | [notion.so/33c4917287518117994fe68400dcdc76](https://www.notion.so/33c4917287518117994fe68400dcdc76) |

### 6.2 Cost Seg Pipeline session (2026-04-08) — what it covered

The April 8 session reviewed cost seg pipeline status across **8 clients**: Augustine, Dan Hamilton, Gil Ramos, Michael Venereo, **Tommy Harr**, **Andy Karabinos**, Matt Iannaccio, and Tate Cline. Both Tommy and Andy (his 50/50 partner) appear together — consistent with the joint partnership stack. The session's title implies it produced a property list + file inventory + follow-up tracker; the output URL above is the canonical record. **Reading priority for next refresh:** fetch the full body of that summary and pull the Tommy + Andy property-specific findings into §9.1 Cost Seg Candidates here. `[Claude 2026-04-08 Cost Seg Pipeline]`

This session is the most likely upstream reason the **13 Cost Seg Proposal Intake rows** exist (see §5.2) — it likely created the parent + 12-sub-item skeleton as a tracking shell, awaiting the property data to be populated by the operations team.

### 6.3 Referral attribution (2026-04-08 New Client Alert Review)

Tommy is recorded as the **referral source for Meghan Botkin**, a new 2026-04-03 Accruity client on the **Foundations+ plan ($2,500 setup + $500/mo retainer)**. This is a meaningful operational data point:
- **Tommy is an active referrer** to Accruity — outsized referral capacity vs current engagement scope
- Combined with Tommy's HIGH-urgency compliance/IRS-balance status, the referral activity reinforces a strategic-theme parallel to Spring Bengtzen's: **the household referral capacity is disproportionate to the engagement revenue**, so service depth on Tommy needs to match the relationship value `[§10.4 Referral & brand value, mirror to Spring's pattern]`
- Confirms Tommy is NOT churning despite the IRS balance + extension stress — he's actively recommending Accruity to others.

`[Claude 2026-04-08 Aidan McIsaac Research + New Client Alert Review §Clients]`

### 6.4 This refresh (2026-04-22) — pending log row

Upon Turn 11 completion, the generator will write a new Claude Summary row with the following shape so the next refresh sees this run on its ingest:

| Field | Value |
| --- | --- |
| Thread Title | `Tommy Harr — Client Intelligence Dossier Refresh — 2026-04-22` |
| Date | 2026-04-22 |
| Account | relation → Tommy Harr (`3424917287518141812be02393d26cb1`) |
| Clients | `Tommy Harr; Andy Karabinos (50/50 partner)` |
| Topics | `File Review`, `Notion Build`, `Compliance`, `Tax Planning`, `Cost Seg`, `S-Corp Restructure` |
| Files Reviewed | Notion Accounts record · Email thread `Re: April 15 - Extension & 2025 Tax Status` · 2 Meetings Tracker rows · 2 sample Cost Seg Proposal Intake rows · 2 prior Claude Summaries (Cost Seg Pipeline, Aidan McIsaac referral review) |
| Notion Pages Created/Updated | `dossiers/TommyHarr/dossier.md` (local) · GitHub mirror branch claude/update-exec-summary-notion-118m7 · Updated: Executive Summaries DB row `34249172875181859bb5c392c42ac4a2` (properties; pointer-only Notion model) |
| Summary | First comprehensive refresh — HIGH-urgency April 15 extension cycle ($28,520 due, awaiting bank info), $196K live IRS balance, $110K amendment savings + $400K dep reclass + S-corp restructure pipeline, 13 cost-seg intake placeholder rows pending population, dual-Account flag on the Feb 11 meeting (possibly Andy's account), 0 ELs / 0 Files & Links / 5 unlinked tax workbooks. Tommy is an active referrer (sourced Meghan Botkin 4/3) — referral capacity > engagement revenue is a strategic theme. |

### 6.5 Cross-stream notes

- **Action carry-over from Cost Seg Pipeline session** — the April 8 session likely produced a follow-up tracker. Confirm next refresh whether any of the 13 Cost Seg Proposal Intake rows trace back to that session as the originating record. If yes, link them.
- **Andy Karabinos parallel coverage** — Andy was reviewed alongside Tommy in the Cost Seg Pipeline session. When Andy gets his own dossier (he's in the missing-rows queue at `docs/BATCH_REFRESH_PROMPT.md`), the §6 there should cross-reference this session and this dossier.
- **Brian Charlesworth-style asymmetric coverage check** — Tommy and Andy share the same partnership stack (50/50). When Andy's dossier is generated, the §10 Operations and §11 Profile sections should flag any asymmetry in service depth between the two partners (mirroring the Spring/Brian flat-fee asymmetry analysis from `dossiers/SpringBengtzen/dossier.md §11.2`).

### 6.6 Gaps to backfill on next refresh

- **Link the 2 prior Claude Summaries to Tommy's Account via the Account relation** — they are searchable but not structurally linked, so any future query scoped to `Account = Tommy Harr` will miss them. Promoted to §7 Action Items as a plumbing item.
- **Pull the full body of the 2026-04-08 Cost Seg Pipeline summary** to populate §9.1 Cost Seg Candidates with the property-level findings that session produced.
- **Read-after-write check on Turn 11** — verify the new Claude Summary row created this refresh resolves the Account relation correctly.

---

## §7. Action Items — Rolled Up

**Scope of this refresh:** Aggregates every open / in-progress action item discovered across §3 Email Intelligence, §4 Meetings, §5 Document Inventory, §6 Claude Work Product, and the dossier-gen plumbing flags. Append-only on subsequent refreshes — closed items flip to strikethrough. **First run — no prior items to carry forward.**

**Rollup counts.** 22 open items across 4 owner-buckets. Oldest dollar-stake item is the **$28,520 April 15 extension balance** (date of write 2026-04-22 — the deadline already passed; first action is to confirm the extension was actually filed with payment processed). Compliance + IRS balance + amendment + cost-seg + S-corp tracks all simultaneously active.

### 7.1 Master Action Items table

| # | Action | Owner | Target | Source | Priority | Opened | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | **Confirm extension was filed before April 15 with the $28,520 payment processed** — the 2026-04-14 thread ended awaiting Tom's bank info; refresh date 2026-04-22 is post-deadline. | Deontae | **Immediate — verify** | `[Email 2026-04-14 Deontae→Tom]` | 🔴 HIGH | 2026-04-14 | 🟡 In Progress (status unknown post-4/15) |
| 2 | **Tommy — provide bank info for extension payment** (or confirm direct online payment was made) | Tommy | Pre-Apr 15 (overdue) | `[Email 2026-04-14 Tom→Deontae]` | 🔴 HIGH | 2026-04-14 | 🟡 In Progress |
| 3 | **Address $23K AMT issue from prior year** in the amendment | Accruity Tax Team | Post-4/15 | `[Email 2026-04-10 Tom→Accruity]` | 🔴 HIGH | 2026-04-10 | 🔴 Open |
| 4 | **Process amendments — $110K combined savings ($65K Tommy + $45K Andy)** | Accruity Tax Team | Post-4/15 | `[EI:Re: April 15 - Extension §Action Items]` | 🔴 HIGH | 2026-02-25 (planning session implied origin) | 🔴 Open |
| 5 | **Office depreciation reclass — $400K basis adjustment** | Accruity Tax Team | Post-4/15 | `[EI:Re: April 15 - Extension §Action Items]` | 🔴 HIGH | 2026-02-25 (planning session implied origin) | 🔴 Open |
| 6 | **S-Corp restructure pipeline** — entity-by-entity scope and timing not yet committed | Seth / Tax Team | Pipeline (post-4/15) | `[EI:Re: April 15 - Extension §Action Items]` | 🟡 MED | 2026-02-25 | 🔴 Open · scope not committed |
| 7 | **Complete cost seg study + populate the 13 Cost Seg Proposal Intake rows** with property addresses, basis, EINs, placed-in-service dates, study fees | Accruity / Tommy | Post-4/15 | `[Accounts:Tommy Harr.Cost Seg Proposals]` `[EI §Action Items]` | 🔴 HIGH | 2026-02-25 (planning session origin) · 2026-04-08 (Cost Seg Pipeline session) | 🔴 Open · 13 placeholder rows awaiting data |
| 8 | **Manage IRS balance** — $196K total ($141K 2023 + $55K 2025) on $12K/month payment plan; $28,520 extension balance compounds against this unless paid with the extension | Tommy / Deontae | Ongoing | `[EI §Key Numbers]` | 🔴 HIGH | (legacy — pre-this-engagement) | 🟡 In Progress · $12K/mo plan |
| 9 | **Resolve dual-Account question** — fetch page `30d49172875181ddb232f4b70fb47e04` (linked to the Feb 11 Tommy + Andy K meeting) and confirm whether it's a duplicate Tommy Account or Andy Karabinos's Account | Accruity ops / Seth | — | `[Meeting 2026-02-11 Tommy + Andy K]` | 🟡 MED (plumbing) | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 10 | **Set Account relation on 2026-02-25 "Thomas Harr" meeting row** — currently empty | Accruity ops | — | `[Meeting 2026-02-25 Thomas Harr]` | 🟢 LOW (plumbing) | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 11 | **Resolve Pending status on 2026-02-11 meeting** — close-out Done/Canceled with reason | Seth / tracker owner | — | `[Meeting 2026-02-11 Tommy + Andy K]` | 🟢 LOW | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 12 | **Locate or originate Tommy Harr engagement letter** — 0 ELs on Account record | Accruity ops / Sophia | ASAP | `[Accounts:Tommy Harr.Engagement Letters]` | 🟡 MED | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 13 | **Originate Files & Links rows for Tommy** — 0 rows currently; Document Inventory + PBC PDF Package URLs need a tracker home as those get populated | Accruity ops | — | `[Accounts:Tommy Harr.Files & Links]` | 🟢 LOW (plumbing) | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 14 | **Locate + link the 5 core tax workbooks to Account** — PBC Workbook, Tax Extraction, Tax Analysis, Tax Memo, Meeting Prep Notes (all empty on Account record) | Accruity ops / Seth | Before next refresh | `[Accounts:Tommy Harr]` | 🟢 LOW (plumbing) | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 15 | **Pull Fellow transcript** for 2026-02-25 Tax Planning Session — extract decision framework | Generator / next refresh | — | `[Meeting 2026-02-25 Thomas Harr]` | 🟢 LOW | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 16 | **Pull MS Teams recording** for 2026-02-10 "Call with Bryan Szpindor" — clarify Bryan's role | Generator / next refresh | — | `[Meeting 2026-02-11 Tommy + Andy K]` | 🟢 LOW | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 17 | **Identify Bryan Szpindor's role** in the engagement (CPA / attorney / lender / investor / other) | Seth | — | `[Meeting 2026-02-11 Tommy + Andy K]` | 🟡 MED | 2026-04-22 (flagged today) | 🔴 Open · third-party orbit gap |
| 18 | **Confirm Sami Bates relationship** — CC'd on April thread, same domain as Tommy; likely spouse/operations partner — confirm | Sophia | — | `[EI §Participants]` | 🟢 LOW | 2026-04-22 (flagged today) | 🔴 Open |
| 19 | **Link 2 prior Claude Summaries to Tommy's Account via structured relation** — currently only searchable by name | Accruity ops / Generator | — | `[Claude 2026-04-08 Cost Seg Pipeline]` `[Claude 2026-04-08 Aidan McIsaac]` | 🟢 LOW (plumbing) | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 20 | **Pull full body of 2026-04-08 Cost Seg Pipeline summary** to populate §9.1 Cost Seg Candidates with property-level findings | Generator / next refresh | — | `[Claude 2026-04-08 Cost Seg Pipeline]` | 🟡 MED | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |
| 21 | **Andy Karabinos dossier creation** — Andy is the 50/50 partner across all 4 operating entities, currently in the missing-rows queue at `docs/BATCH_REFRESH_PROMPT.md`. Generate his dossier and cross-reference this one. | Generator / next refresh | — | `[CLAUDE.md §Remaining queue]` | 🟡 MED | 2026-04-22 (flagged today) | 🔴 Open · queued |
| 22 | **Outlook live scan** for `tom@legacyohiohomes.com` / `realsiderealestate@gmail.com` / `sami@legacyohiohomes.com` / `legacyohiohomes.com` domain over the last 18 months — backfill missing email threads | Generator / next refresh | — | `[Gap §3.4]` | 🟡 MED | 2026-04-22 (flagged today) | 🔴 Open · dossier-gen flagged |

### 7.2 Owner rollup

| Owner | Open | In Progress | HIGH priority | Notes |
| --- | --- | --- | --- | --- |
| **Tommy** | 1 (#2) | 1 (#2) | 1 | Bank info / extension payment confirmation |
| **Deontae (Tax Compliance)** | 2 (#1, #8) | 2 | 1 | Active thread owner |
| **Sophia (Tax Admin)** | 2 (#12, #18) | — | 0 | EL origination + Sami confirmation |
| **Accruity Tax Team** | 4 (#3, #4, #5, #7) | — | 4 | Amendment + dep reclass + cost seg + AMT |
| **Seth (RM)** | 2 (#6, #17) | — | 0 | S-corp scope + Bryan ID |
| **Accruity ops / Generator** | 11 (#9, #10, #11, #13, #14, #15, #16, #19, #20, #21, #22) | — | 0 | All plumbing / dossier-gen flagged |

### 7.3 Source count

| Source | Items contributed |
| --- | --- |
| Email thread `Re: April 15 - Extension & 2025 Tax Status` (§3) | 8 (#1–#8) |
| Meetings (§4) | 3 (#9, #10, #11) |
| Document Inventory (§5) | 3 (#12, #13, #14) |
| Claude Work Product (§6) | 2 (#19, #20) |
| Operations / cross-refs (§3 Sami, §4 Bryan) | 2 (#17, #18) |
| Generator/queue plumbing | 4 (#15, #16, #21, #22) |
| Meeting Action Items DB | 0 (none tied to Tommy account) |
| Engagement Inquiries DB | 0 |
| Service Requests DB | 0 |
| Intake Requests DB | 0 |

### 7.4 Gaps / not-yet-captured

- **No Meeting Action Items DB rows exist** for either of Tommy's 2 logged meetings. The 02-25 Tax Planning Session clearly produced action items (the amendment + dep reclass + cost-seg + S-corp pipeline are effectively its output) — those items live in the email thread today, not as DB rows. On next refresh, **back-fill Meeting Action Items DB rows** so they're queryable by owner + due date.
- **Andy-side action items not captured here.** Andy's $45K share of the amendment savings, his side of the cost-seg pipeline, and his S-corp structure are Tommy-parallel but Tommy's Account doesn't surface them. Pick up on Andy's dossier when generated.
- **Engagement Inquiries / Service Requests / Intake Requests** — all return zero for Tommy this refresh. Either no requests have been filed, or they exist but aren't linked to the Account. Verify next refresh.

---

## §8. Tax Strategies & Projected Savings

**Scope of this refresh:** Strategy lines anchored in the April 9–14 email thread and the 2026-02-25 Tax Planning Session (transcript pending). The **Tax Planning Memo, Tax Analysis Workbook, Insights Delivery Workbook, and PBC Workbook are all unlinked** on the Account record (§5.4), so projected-savings figures that aren't quoted directly in the email thread are marked `? Pending workbook ingestion`. **No fabricated $ figures** — every dollar value below is sourced from the email thread or marked `?`.

### 8.1 Strategy table

| Strategy | Entity / Property | Est. Impact | Status | Year | Priority | Source |
| --- | --- | --- | --- | --- | --- | --- |
| **April 15 extension + payment** | Personal 1040 | `$28,520` balance due covered with extension payment | In Progress — awaiting Tom's bank info as of 2026-04-14 | 2025 | 🔴 HIGH | `[EI:Re: April 15 - Extension §Synopsis]` |
| **Prior-year amendment to capture $110K combined savings** ($65K Tommy + $45K Andy) | Tommy + Andy 1040s | **$65,000** Tommy share | Open · post-4/15 deliverable | Prior year (2023 likely) | 🔴 HIGH | `[EI §Key Numbers]` `[EI §Action Items]` |
| **AMT issue resolution** ($23K from prior year) | Tommy 1040 | `$23,000` (component of the $65K above) | Open · to be addressed in the same amendment | Prior year | 🔴 HIGH | `[Email 2026-04-10 Tom→Accruity]` |
| **Office depreciation reclass** | (entity TBD — likely Legacy Ohio Homes office property or LHI) | `$400,000` basis adjustment | Open · post-4/15 deliverable | 2025 + amendment | 🔴 HIGH | `[EI §Action Items]` `[EI §Key Numbers]` |
| **Cost segregation study** | TBD properties (13 intake rows pending population) | ? Pending property data | Open · post-4/15 · 13 placeholder rows in Cost Seg Proposal Intake DB | 2025 + 2026 | 🔴 HIGH | `[Accounts:Tommy Harr.Cost Seg Proposals]` `[EI §Action Items]` `[Claude 2026-04-08 Cost Seg Pipeline]` |
| **S-Corp restructure** (entity-by-entity) | Likely Legacy Ohio Homes + COGS ULTD (the active operating partnerships with $260K + $312K Tommy K-1 income) | ? Pending net-SE-by-entity computation | Open · pipeline · scope/timing not committed | 2026 | 🟡 MED | `[EI §Action Items]` |
| **REPS (Real Estate Professional Status) evaluation** | Tommy and/or Andy | ? Pending hours-of-participation log; Tommy's RE operator profile (Real Side Real Estate brokerage + LHI rental management + Legacy Ohio Homes operating) suggests likely qualification, would unlock LHI rental losses against active income | Not formally claimed in the file | 2025 + 2026 | 🟡 MED | `? Pending memo ingestion` `[EI §Synopsis: "rental losses don't reduce SE"]` |
| **STR / material-participation evaluation** for the LHI rental portfolio | LHI properties | ? Pending property type breakdown — depends on whether any LHI properties are short-term rentals | Not determinable without PBC workbook + rental schedule | 2025 | 🟡 MED | `? Pending workbook ingestion` |
| **Augusta Rule (§280A(g)) evaluation** for any meeting/use of Tommy's primary residence by the partnerships | Personal residence → operating entities | ? Pending — not in scope of email thread | Not evaluated | 2026 | 🟢 LOW | `? Pending memo ingestion` |
| **Accountable plan for reimbursable business expenses** | Tommy + Andy → operating entities | ? Pending 2024/2025 expense mix | Not evaluated | 2026 | 🟡 MED | `? Pending memo ingestion` |
| **Retirement plan / SEP-IRA / Solo 401(k) optimization** | Tommy (and possibly entity-level on Legacy Ohio Homes / COGS ULTD) | ? Pending W-2 + K-1 detail | Not evaluated in file | 2025 + 2026 | 🟡 MED | `? Pending memo ingestion` |

### 8.2 Projected savings rollup

| Bucket | Quantified | 2025 Impact | Prior-Year Amendment | Source |
| --- | --- | --- | --- | --- |
| Amendment ($110K combined) — Tommy share | ✓ | — | **$65,000** | `[EI §Key Numbers]` |
| AMT issue (component of amendment) | ✓ | — | $23,000 (in $65K) | `[EI §Key Numbers]` |
| Office dep reclass | ~ partial | (depends on year of reclass) | — | `[EI §Key Numbers]` ($400K basis adj.) |
| Cost seg study (TBD properties) | ❌ | ? | — | `[Accounts:Tommy Harr.Cost Seg Proposals]` |
| S-Corp restructure SE savings | ❌ | ? | — | `[EI §Action Items]` |
| REPS / STR loss-usability optimization | ❌ | ? | — | `? Pending memo ingestion` |
| **Total quantified** | — | **? Pending** | **$65,000 (+$45,000 Andy share)** | — |

### 8.3 Gaps to backfill next refresh (strategy side)

- **Tax Planning Memo (Feb 2026 Tax Planning Session output)** — the 2026-02-25 session likely produced a memo that quantifies the office dep reclass + cost seg + S-corp impacts. Locate + link to Account.
- **Tax Analysis Workbook** — net-SE-by-entity numbers needed for the S-corp election analysis.
- **Insights Delivery Workbook** — prior-year baseline + the W-2 source confirmation.
- **PBC Workbook** — entity stack reconciliation + property schedule for cost-seg classifier.
- **REPS hours log** for Tommy — would materially upgrade the priority of the LHI rental losses + cost seg cascade.

---

## §9. Opportunity Flags (auto-detected)

Rule-based classifier from `execsumm_emails/opportunity_flags.py`. Same caveat as Spring's §9: classifier depends on per-property basis + placed-in-service + study status (Cost Seg) and per-entity net SE earnings + classification + activity (S-Corp). Those inputs are not yet in the file (§5.4 + §5.2 — 13 cost-seg intake rows are empty placeholders), so most rows are `? Pending`. HIGH flags auto-promote to §7.

### 9.1 Cost Segregation Candidates

| Property | Entity Owner | Basis | Placed in Service | Study Status | Est. Bonus Dep | Priority | Basis of Flag | Source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **(13 unnamed intake-row placeholders)** | TBD (likely LHI portfolio + possibly Legacy Ohio Homes office) | ? Pending | ? | "New - Enter in Portal" (not commissioned) | ? Pending | 🟡 **PENDING DATA** | Intake-form skeleton exists but no property data populated; can't classify HIGH/MEDIUM/LOW until rows are filled | `[Accounts:Tommy Harr.Cost Seg Proposals]` `[§5.2]` |
| **LHI rental portfolio** (the rental engine producing the $922K 50% nonpassive losses) | LHI partnership | ? Pending | ? Pending | None commissioned | ? Pending | 🔴 **HIGH** (qualitative, awaiting basis data) | $1.5M mortgage interest implies large basis · rental real estate · loss usability path likely already established (the K-1 already shows $922K nonpassive losses, suggesting REPS or material participation is being claimed) — **strongest candidate in the file** for cost seg priority once basis is known | `[EI §Key Numbers]` |
| **Legacy Ohio Homes office property** ($400K dep reclass referenced) | Legacy Ohio Homes | ~$400K (basis adjustment) | ? Pending | None — but $400K reclass is in flight | ? Pending | 🔴 **HIGH** (related but distinct from cost seg — this is a reclassification, not a new study) | The $400K office dep reclass is a separate item from a property-level cost seg study; it may overlap but should be tracked separately | `[EI §Key Numbers]` `[EI §Action Items]` |

**Read:** the LHI rental portfolio is **the strongest cost-seg priority** in the file. The $922K loss already on the K-1 means the loss-usability path is established (REPS / material participation), so any additional cost-seg-driven acceleration would flow directly through to active income offset (or further negative AGI). The basis is unknown — but $1.5M of mortgage interest implies a portfolio basis substantially north of $1.5M. Even at $3M basis × 25% × 60% bonus = ~$450K incremental first-year deduction (illustrative; pending actual basis).

### 9.2 S-Corp Election Candidates

| Entity | Current Classification | 2025 Net SE Earnings (Tommy 50%) | Reasonable Salary | Est. SE Savings | Priority | Basis of Flag | Source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Legacy Ohio Homes** | 1065 partnership (K-1 of $312K Tommy 50%) | **$312,472** | ~$94K (30% of net SE) | ~`$30K` Tommy / `$60K` combined w/ Andy | 🔴 **HIGH** | Net SE earnings ≥ $80K threshold by ~4×; active operating partnership; SE tax of $35K total in 2025 confirms SE exposure on the active income | `[EI §Key Numbers]` `[EI §Action Items: S-Corp restructure]` |
| **COGS ULTD** | 1065 partnership (K-1 of $260K Tommy 50%) | **$260,178** | ~$78K (30% of net SE) | ~`$25K` Tommy / `$50K` combined w/ Andy | 🔴 **HIGH** | Net SE earnings ≥ $80K threshold by ~3×; active operating partnership | `[EI §Key Numbers]` `[EI §Action Items: S-Corp restructure]` |
| **LHI** (rental portfolio) | 1065 partnership | -$922K (passive rental losses) | — | — | **NOT APPLICABLE** | Rental holding entity with depreciable RE — S election would create distribution-gain recognition risk on appreciated RE; the rental losses are nonpassive only because of REPS/material participation, but the entity itself is rental real estate | `[EI §Key Numbers]` |
| **B&M Management** | 1065 partnership | -$71K (loss) | — | — | **NOT APPLICABLE** (current) | Loss entity; no SE tax to eliminate; reconsider once activity shifts to net-positive | `[EI §Key Numbers]` |
| **Real Side Real Estate** | TBD (possibly W-2 source — $48K Tommy wages 2025) | ? Pending classification | — | — | ? Pending | If Tommy is a W-2 employee here it's likely already an S-corp or 1120; if it's a Schedule C / LLC he runs, S election may be MEDIUM priority | derived from `realsiderealestate@gmail.com` contact email |

**S-Corp savings rollup** (combined Tommy + Andy across the two HIGH-priority entities):
- Legacy Ohio Homes: ~`$60K/yr` SE-tax savings (combined)
- COGS ULTD: ~`$50K/yr` SE-tax savings (combined)
- **Combined: ~`$110K/yr` ongoing SE tax reduction** if both elections + reasonable salary structure are implemented

This is approximately **the same magnitude as the prior-year amendment savings ($110K combined)** — meaning the S-corp restructure is structurally a recurring annual benefit on top of the one-time amendment. Strongly supports the priority of completing the S-corp restructure pipeline (Action #6) post-4/15.

### 9.3 Classifier coverage this refresh

| Metric | Value |
| --- | --- |
| Properties scanned for Cost Seg | 0 properties with actual data; 13 placeholder rows; 1 implicit aggregate ("LHI portfolio") + 1 office reclass scope |
| Entities scanned for S-Corp | 5 named; 2 numerically scored HIGH (Legacy Ohio Homes, COGS ULTD); 2 ruled out NOT APPLICABLE (LHI, B&M); 1 ? Pending (Real Side Real Estate) |
| HIGH flags promoted to §7 Open Items | 4 (LHI cost seg ⊃ Action #7; office reclass ⊃ Action #5; Legacy Ohio Homes S-corp ⊃ Action #6; COGS ULTD S-corp ⊃ Action #6) |
| Combined ongoing SE-tax savings opportunity (S-corp) | ~`$110K/yr` (combined Tommy + Andy) |
| Cost Seg engagements already in flight | 0 (13 placeholder rows + the planned post-4/15 study) |

### 9.4 Gaps to backfill next refresh (opportunity-flag side)

- **Populate the 13 Cost Seg Proposal Intake rows** with property addresses, basis, EINs, placed-in-service dates, and study fees so the §9.1 classifier can run with real data.
- **PBC Workbook property schedule** — once linked, every LHI property gets its own row in §9.1.
- **Confirm REPS status formally** for Tommy (and Andy) — would lock in the loss-usability path that's currently inferred from the $922K nonpassive losses on the K-1.
- **Net SE earnings per entity** from the Tax Analysis Workbook — sharpens the S-corp savings estimates from rough rule-of-thumb to precise.
- **Real Side Real Estate classification** — confirm whether Tommy's W-2 is from this entity and what its current federal form is.

---

## §10. Operations Analysis

**Scope this refresh:** derived from the April email thread, the 2 Meetings Tracker rows, and the 2 prior Claude sessions. Tommy and Andy operate a **vertically-integrated Ohio real-estate platform** spanning brokerage (Real Side Real Estate), homebuilder/operating (Legacy Ohio Homes + COGS ULTD), rental holdings (LHI portfolio), and a management entity (B&M Management). The model is structurally similar to a Spring/Brian-style household but with a **single 50/50 partner pair** (Tommy + Andy) instead of a married couple — and with the partnership entirely concentrated on real-estate operations rather than mixed RE-and-software.

### 10.1 The operating engine

**Top of funnel — Real Side Real Estate (brokerage).** Tommy's `realsiderealestate@gmail.com` contact email plus a $48K W-2 in 2025 strongly suggest Tommy holds a brokerage role at this entity (or it's his own brokerage). Brokerage activity is plausibly the deal-flow source feeding the operating + holding entities below. Federal form unknown until confirmed in §5 documents. `[Accounts:Tommy Harr.New Contact: Email]`

**Core operating partnerships — Legacy Ohio Homes + COGS ULTD.** Both entities are 50/50 with Andy. Combined 2025 K-1 income on Tommy's side: **$572,650** ($312,472 Legacy Ohio Homes + $260,178 COGS ULTD). The names suggest a homebuilder / property-development model — Legacy Ohio Homes likely the build/sell entity, COGS ULTD likely the cost-of-goods/development services entity. SE tax ($35K total at 2025) hits because these are active-business K-1s (not rental). `[EI §Key Numbers]`

**Rental holding — LHI.** 50/50 with Andy. **2025 50% rental losses: $922K**, driven by `$1.5M` of mortgage interest on the LHI portfolio. The loss is recorded as **nonpassive**, which means either (a) Tommy/Andy have qualified for **REPS** (Real Estate Professional Status), or (b) the properties are **STR** with material participation, or (c) the LHI structure is being treated as a self-rental. Whichever applies, the K-1 already reflects nonpassive treatment — this is the engine that drives Tommy's 2025 AGI to negative. `[EI §Key Numbers]` `[EI §Synopsis]`

**Loss-of-record entity — B&M Management.** 50/50 with Andy. 2025 50% loss: $71K. Likely a management-services entity that bills the operating partnerships at cost or below cost. `[EI §Key Numbers]`

### 10.2 IRS posture (current)

- **Live IRS balance: $196,000** ($141K relating to 2023 + $55K accruing on 2025) on a **$12,000/month payment plan** `[EI §Key Numbers]`
- **2025 extension balance: $28,520** added on top — handling outcome of the Apr 14 thread is the immediate gate `[EI §Key Numbers]`
- **2024 AMT issue: $23,000** carried over from prior year, expected to be resolved as part of the amendment work `[Email 2026-04-10 Tom→Accruity]`

### 10.3 Coverage model + cadence

**Accruity coverage.** Deontae Lafayette (Tax Compliance) owns the active April thread; Sophia Leonardo (Tax Admin) is the portal/admin contact; Seth Johnson (RM) and Stacy Cvengros are CC'd; `tax@accruity.com` is on the team-inbox CC list. Sami Bates is CC'd from the client side, indicating she has visibility into tax/financial conversations. `[EI §Participants]`

**Meeting cadence.** 2 logged meetings in early 2026 (Feb 11 ad-hoc with Bryan Szpindor, Feb 25 Tax Planning Session). 56-day gap from last meeting to this refresh. ~6 weeks before the April extension thread opened, the Feb 25 session likely produced the strategic framework (amendment + dep reclass + S-corp + cost-seg) currently in flight. `[§4.4]`

### 10.4 Referral & brand value (operational context)

Tommy is **an active referrer to Accruity**. The 2026-04-08 New Client Alert review explicitly records Tommy as the source for **Meghan Botkin** (4/3 new client, $2,500 Foundations+ + $500/mo retainer). `[Claude 2026-04-08 Aidan McIsaac §Clients]` Combined with his HIGH-urgency compliance/IRS-balance status, the referral activity is a strong signal: **Tommy is not at relationship risk despite the financial stress**, and the engagement is producing follow-on revenue beyond Tommy's direct fees.

Mirroring the Spring/Brian strategic theme: **referral capacity exceeds engagement revenue.** The investment in resolving Tommy's amendment + cost seg + S-corp pipeline is justified not just by the direct economics ($110K amendment + $110K/yr ongoing S-corp savings) but by the referral network it sustains.

### 10.5 Risk posture

| Risk | Current state | Mitigation |
| --- | --- | --- |
| **April 15 cycle compliance** | $28,520 due; Tom's bank info pending Apr 14 (refresh date Apr 22 — already past deadline) | Confirm extension was filed with payment (Action #1) |
| **IRS payment plan integrity** | $12K/mo plan against $196K balance; new $28,520 compounds against this if extension wasn't paid | Pay extension balance to keep plan clean |
| **Amendment timing** | $110K combined + $23K AMT; post-4/15 work | Build amendment workpapers; file once 4/15 cycle clears |
| **Cost seg pipeline stall** | 13 intake placeholder rows since (date unclear); none populated; no studies commissioned | Populate intake → commission studies → §9.1 classifier runs with real data |
| **S-corp restructure inertia** | Pipeline-only; entity scope/timing not committed | Use the $110K/yr ongoing-savings frame to drive prioritization (Action #6) |
| **Andy-side coverage gap** | Andy is a separate Account that doesn't yet have a dossier; his $45K amendment share + S-corp stake + cost seg interest live in his own context | Generate Andy dossier next; cross-reference here (Action #21) |
| **Documentation gap** | 0 ELs, 0 Files & Links rows, 5 unlinked tax workbooks | Plumbing items (#12–#14) — backfill before next refresh |
| **Dual-Account flag** | The Feb 11 meeting points to a different Account ID — possibly a duplicate Tommy or Andy's account | Resolve next refresh (Action #9) |

---

## §11. Individual Profile(s)

### 11.1 Tommy Harr

| Dimension | Detail | Source |
| --- | --- | --- |
| Role | Operator/principal across the Legacy Ohio Homes / COGS ULTD / LHI / B&M Management stack; brokerage role at Real Side Real Estate (likely) | derived from `[Accounts:Tommy Harr]` + `[EI §Key Numbers]` |
| Email (operating) | `tom@legacyohiohomes.com` | `[Accounts:Tommy Harr.New Contact: Email]` |
| Email (brokerage) | `realsiderealestate@gmail.com` | `[Accounts:Tommy Harr.New Contact: Email]` |
| Phone | `(614) 406-0997` | `[Accounts:Tommy Harr.New Contact: PH#]` |
| Tax filing status | Likely MFJ (Sami Bates CC'd, possibly spouse) — `? Pending confirmation` | `[EI §Participants]` |
| Residency | Ohio (operating entities domiciled in Ohio; area code 614 = Columbus) | derived |
| W-2 income (2025) | $48,000 (likely sourced from Real Side Real Estate or one of the operating entities) | `[EI §Key Numbers]` |
| 2025 K-1 income (Tommy 50%) | +$312K Legacy Ohio Homes + $260K COGS ULTD = **+$572K active** | `[EI §Key Numbers]` |
| 2025 K-1 losses (Tommy 50%) | -$922K LHI rentals + -$71K B&M Management = **-$993K** | `[EI §Key Numbers]` |
| 2025 net K-1 position | **-$421K** (rental losses fully offset active K-1 income) → negative AGI | `[EI §Key Numbers]` |
| 2025 SE tax exposure | **$35,000** (rental losses don't reduce SE; SE applies to active K-1 income) | `[EI §Key Numbers]` |
| IRS balance (across years) | **$196,000** total ($141K 2023 + $55K 2025) on $12K/month plan | `[EI §Key Numbers]` |
| 2025 extension balance due | **$28,520** (as of Apr 14 thread; may already be paid post-Apr 15) | `[EI §Key Numbers]` |
| Engagement letter | Not on file ⚠️ (Action #12) | `[Accounts:Tommy Harr.Engagement Letters]` |
| Active engagement tracks | Compliance + Amendment ($110K combined savings) + Cost Seg + Office Dep Reclass ($400K) + S-Corp restructure pipeline | `[EI §Action Items]` |
| Wealth picture | Active operator with negative-AGI tax shelter via LHI rentals; underlying balance-sheet equity in Legacy Ohio Homes / COGS ULTD / LHI portfolio likely substantial (8-figure portfolio implied by $1.5M mortgage interest + active brokerage) but not quantified in file | derived |
| REPS posture | Likely qualifies given multi-entity RE operator status; nonpassive treatment of $922K LHI losses suggests already being claimed — formal hours-log documentation pending | `[EI §Key Numbers]` `[EI §Synopsis]` |

**Life events / third-party context.**
- **Bryan Szpindor** entered the orbit on 2026-02-10 via an MS Teams call. Role unclear (CPA / attorney / lender / investor / contractor — Action #17 to identify).
- **Sami Bates** (`sami@legacyohiohomes.com`) — same domain as Tommy, CC'd on the April thread; likely spouse or operations principal (Action #18).
- **Andy Karabinos** — 50/50 partner across the entire entity stack; needs his own dossier.

**Stated priorities (from the file).**
- 2026-04-10: "wants to pay [extension] with extension" and "address the $23K AMT issue in the amendment" `[Email 2026-04-10 Tom→Accruity]`
- 2026-04-14: offered bank info for extension payment, asked if `$6,000` payment was recommended `[Email 2026-04-14 Tom→Deontae]`

**Outstanding to Tommy personally.** 1 in-progress action item (#2 — bank info for extension payment). Several Accruity-owned but Tommy-facing items follow ($23K AMT, $65K Tommy-share amendment, S-corp scope, cost seg).

**Relationship-risk read.** **LOW** — Tommy is financially stressed (IRS balance + extension cycle) but operationally engaged, prompt in his replies (same-day responses on Apr 10 and Apr 14), and actively referring new business (sourced Meghan Botkin 4/3). The risk is on the Accruity side: failing to convert the $110K amendment + $110K/yr S-corp restructure + LHI cost-seg pipeline into real deliverables would erode trust over time. Tommy is the kind of client where execution speed materially shapes long-term value.

### 11.2 Andy Karabinos (50/50 partner — coverage stub)

| Dimension | Detail | Source |
| --- | --- | --- |
| Role | 50/50 partner with Tommy across Legacy Ohio Homes, COGS ULTD, LHI, B&M Management | `[EI §Key Numbers]` |
| Status as Accruity client | Pending — Andy is in the missing-rows queue at `docs/BATCH_REFRESH_PROMPT.md` | `[CLAUDE.md §Remaining queue]` |
| Andy's 2025 K-1 income share | Mirrors Tommy at 50% — same dollar amounts on his side: +$312K + $260K - $922K - $71K = -$421K net | `[EI §Key Numbers]` |
| Amendment share | **$45,000** (component of $110K combined Tommy+Andy amendment savings) | `[EI §Key Numbers]` |
| Other Accruity touchpoints | Joint Feb 11 meeting (Tommy + Andy K Tax Discussion); 2026-04-08 Cost Seg Pipeline Claude session reviewed Andy alongside Tommy | `[Meeting 2026-02-11 Tommy + Andy K]` `[Claude 2026-04-08 Cost Seg Pipeline]` |
| Engagement letter | Not on file (assumed parallel to Tommy's — Action #12 includes both) | derived |

**Coverage instruction for next refresh.** When Andy's dossier is generated (he's queued in the missing-rows list), it should:
- Cross-reference this Tommy dossier as the partner reference
- Inherit the same key-numbers structure (mirror at 50%)
- Run §9 Opportunity Flags independently — same entities, same HIGH cost-seg + S-corp candidates
- Apply the asymmetric-service-depth check that came out of Spring's §11.2 (the analog for partnerships: are Tommy and Andy receiving symmetric Accruity coverage, or is one partner driving the engagement while the other gets thinner service?). The Apr 14 thread CC'd only Tommy (not Andy); flag this as a possible asymmetry until confirmed.

---

## §12. Provenance Index

Every non-obvious fact in this dossier carries an inline source tag. This index lists every tag used above with a direct link. Alphabetical within each category.

### 12.1 Notion — Account record
- `[Accounts:Tommy Harr]` → [notion.so/3424917287518141812be02393d26cb1](https://www.notion.so/3424917287518141812be02393d26cb1)
- `[Accounts:Tommy Harr.Email Log]` · `[Accounts:Tommy Harr.Engagement Letters]` · `[Accounts:Tommy Harr.Files & Links]` · `[Accounts:Tommy Harr.Cost Seg Proposals]` · `[Accounts:Tommy Harr.Meetings]` · `[Accounts:Tommy Harr.New Contact: Email]` · `[Accounts:Tommy Harr.New Contact: PH#]` — properties on the Account page above
- ⚠️ Suspected duplicate Account at [notion.so/30d49172875181ddb232f4b70fb47e04](https://www.notion.so/30d49172875181ddb232f4b70fb47e04) (linked from the Feb 11 meeting; possibly Andy Karabinos's Account — Action #9)

### 12.2 Notion — Client Email Log
- `[EI:Re: April 15 - Extension & 2025 Tax Status …]` → [notion.so/34249172875181ae9397f58a504e0957](https://www.notion.so/34249172875181ae9397f58a504e0957) — [Outlook](https://outlook.office365.com/owa/?ItemID=AAMkADBmZjg2NGQ4LTFhNTgtNGI2Mi05MmJmLTlhMWZkNDVkMjVkZQBGAAAAAAAY75o7uPA2RpuX8UEo5dXBBwBwW9uyQOvRTKnXOw4wkwFeAAAAAAEMAABwW9uyQOvRTKnXOw4wkwFeAAQ8ogn2AAA%3D&exvsurl=1&viewmodel=ReadMessageItem)
- `[Email 2026-04-09 Accruity→Tom "April 15 - Extension"]` · `[Email 2026-04-10 Tom→Accruity]` · `[Email 2026-04-14 Deontae→Tom]` · `[Email 2026-04-14 Tom→Deontae]` — messages within same thread

### 12.3 Notion — Meetings Tracker
- `[Meeting 2026-02-11 Tommy + Andy K]` → [notion.so/30449172875180ed92f8e8f541eeb727](https://www.notion.so/30449172875180ed92f8e8f541eeb727) — [MS Teams recap](https://teams.microsoft.com/l/meetingrecap?driveId=b%219Sy6PCqW-k-mi_pkBBdtAnmxOhkZ9z9DnB1ebRRhIxorE7g_sYChQIEPQYfrGcNH&driveItemId=01SRMA4TPXZP722266UJGZTF4BZETURQB5)
- `[Meeting 2026-02-25 Thomas Harr]` → [notion.so/314491728751804eb9cfd1eb0ba5a507](https://www.notion.so/314491728751804eb9cfd1eb0ba5a507) — [Fellow recap](https://sg5.fellow.app/uni/ls/click?upn=u001.Y1tiWTgJ1PJMrKyj7dbJHqPp-2FT6JwyJKYnLKCSUh0dRKOQm2cj6PWWcYw1WzaV8IB9FGQODOjD0Q-2B5JJcCrN5BRAOPWH3ooUhVUuFVrRbbcKvq39JUo20X8G6-2FzaK8u5-2BDRYjdRd7ccspDaY-2FNEwPsx-2BmtvaUoNrHlT76DG3EqkdDJOMNCUTWrfeY09EhHMpTvlSLREAcGCle1z0EQ-2FFnRwhg1-2FIIS8C6IBMVFkyfWhp7w-2BxyknOlw5ZK9nOYxk-2BwdQ6jEFpyB12n1aRJb9B73fbr4Pslhn5u9-2F0IqpbmU2hH7460Ixy4IRd2HhvdT-2FsZnymnKd-2B3TOjpyQIY-2Bv3B9ZYyVDk-2BNFDDKvvlY8SE1kHJaB1jsWD5BgmRQsBDNIhKiuh5AY0sH1w9q8nCULikaIvB5knh5oCwFZdC-2BscOY8ipHN0-2FwCOGj4RFT2Jjx-2BwUX3yQboIRQ7cXM4dAv3G5FFVzHv030sU8jPsExpXJy4UajTekbmTk9ledqy7ZJA3RP-2BKm3C2LOCmHrdYgD-2BeOHVe9JOQqxhV4CiGyRhDS9oaMI9oRbZEYssGScwZEUcg44km_nCyD0OjfWWda0fny7BdXCaZa1dTuV49YyfNg3yJrg97FL3Kv0EHJMcicPdkuqwuRdzjRrm80tEQd1-2BziUVdt4N-2BENqkwrYnMwunCF16u8LRHLYXwliaO-2FRxCTdaxoscX0qRzlE7rIioEu87itWKBhA35b-2BLtpeZdY5FttszEKk98S-2BAkQjeAEezMXDnx4Erip9FzEXDDzYaOs5Vcm1AsYb-2BgpyoamtklMs0g2uty2jkLjDmv7S713h0dFNaejm6R4aacY7tM-2BP0Ba2zS1tS4g4lNk1ZUqKdUjExLsKx4IXKxbWGPcQL0vxW8Qyj2yn4a5ix4R0g2Yru3eRWmZLGhh84fwBeZSH3h12ETm6-2Fl4qe2Nre9VtgjSdgNHHF7M5rgOoyImZHHDfOL1RD170sXKpdh22SsY9Id4F65zZHdaDFbEcH-2BNR2-2FGFymfze07EF4)

### 12.4 Notion — Cost Seg Proposal Intake DB
- `[Cost Seg Proposal status]` — 13 rows on Account; parent `3484…7344` + 12 sub-items, all Status "New - Enter in Portal" with no property data populated
- Sample child fetched: `34849172875180e2bbc4d307522d9b0b` (deleted/empty)

### 12.5 Notion — Claude Summaries
- `[Claude 2026-04-08 Cost Seg Pipeline]` → [notion.so/33c49172875181098390e5d079955549](https://www.notion.so/33c49172875181098390e5d079955549) — multi-client review (Tommy + Andy + 6 others)
- `[Claude 2026-04-08 Aidan McIsaac Research + New Client Alert Review]` → [notion.so/33c4917287518117994fe68400dcdc76](https://www.notion.so/33c4917287518117994fe68400dcdc76) — recorded Tommy as referral source for Meghan Botkin

### 12.6 In-dossier back-references
- `[§3 Email Intelligence]` · `[§3.4 Gaps]` · `[§4.4 Rollup]` · `[§5.2 Cost Seg Proposal Intake nuance]` · `[§5.4 Files still missing]` · `[§7.1 Master Action Items table]` · `[§9.1 Cost Seg Candidates]` · `[§10.4 Referral & brand value]` · `[§11.2 Andy Karabinos coverage stub]`

### 12.7 Cross-dossier references
- `[dossiers/SpringBengtzen/dossier.md §11.2 Relationship-risk read]` — strategic-theme parallel for asymmetric service depth

### 12.8 Gap markers
- `[Gap: Outlook live scan deferred]` — no live Outlook scan run this refresh
- `[Gap: Fellow transcript ingestion]` · `[Gap: transcript ingestion]` — transcript URLs captured but not ingested
- `[? Pending workbook ingestion]` · `[? Pending memo ingestion]` — strategy/opportunity rows awaiting linked workbooks/memo

---

## §13. Changed Since Last Refresh

**This is the first comprehensive refresh.** No prior dossier existed for Tommy Harr; the existing Notion state was a shell Executive Summaries DB row (`34249172875181859bb5c392c42ac4a2`) with empty body and properties.

### 13.1 · 2026-04-22 · First-run baseline

**New — factual integrations assembled across sources:**
- Account record + email thread + meetings + cost seg proposals + 2 prior Claude sessions integrated into one canonical profile.
- Engagement scope quantified end-to-end: $48K W-2 · $572K active K-1 income · $922K LHI rental losses · $35K SE tax · $28,520 extension balance · $196K IRS balance ($141K 2023 + $55K 2025) · $12K/mo payment plan · $110K combined amendment savings ($65K Tommy + $45K Andy) · $400K office dep reclass · $23K AMT · $1.5M LHI mortgage interest · safe-harbor $52,981 · Tom's proposed $6K payment.
- Rolled-up master Action Items table of **22 items** across 6 owner-buckets covering compliance + IRS + amendment + dep reclass + cost seg + S-corp + plumbing.

**New — discoveries that had not previously been flagged:**
- ⚠️ **Dual-Account flag**: the 2026-02-11 Tommy + Andy K meeting row points to Account `30d49172…7e04` instead of this dossier's anchor `34249172…2cb1`. Either duplicate Tommy Account exists or it's Andy Karabinos's Account (Action #9).
- ⚠️ **13 Cost Seg Proposal Intake rows are empty placeholders** — they look like an active pipeline but contain no property data (parent + 12 sub-items, all Status "New - Enter in Portal"). The actual cost seg study is post-4/15 work that has not begun. Real classifier output blocked until populated.
- ⚠️ **0 Engagement Letters · 0 Files & Links rows · 5 unlinked tax workbooks** — substantial documentation gap on a HIGH-urgency engagement.
- **Bryan Szpindor** — new third party in the orbit (Feb 10 MS Teams call); role unidentified (Action #17).
- **Sami Bates** — `sami@legacyohiohomes.com`, CC'd on April thread, likely spouse/operations (Action #18).
- **Tommy is an active referrer** — sourced Meghan Botkin (4/3 new Foundations+ client at $2,500 + $500/mo). Strategic-theme parallel to Spring/Brian: referral capacity exceeds engagement revenue.
- **2026-02-25 "Thomas Harr" meeting has no Account relation populated** (Action #10).

**New — rule-based auto-detected flags (§9):**
- **2 HIGH Cost-Seg candidates** (qualitative pending basis): LHI rental portfolio (strongest priority — $1.5M mortgage interest implies large basis, loss-usability path established via $922K nonpassive losses) + Legacy Ohio Homes office reclass ($400K basis adjustment).
- **2 HIGH S-Corp candidates**: Legacy Ohio Homes ($312K Tommy 50% net SE, ~$60K combined annual SE savings) + COGS ULTD ($260K Tommy 50%, ~$50K combined). **Combined ~$110K/yr ongoing SE-tax savings** — same magnitude as the one-time amendment.
- **NOT APPLICABLE** rule-outs: LHI (passive rental holding with appreciated RE — distribution gain risk) · B&M Management (loss entity, no SE to eliminate).
- **? Pending classification**: Real Side Real Estate.

**New — strategic themes surfaced for the first time in an integrated record:**
- **Combined ~$110K/yr S-corp recurring savings + $110K one-time amendment + LHI cost-seg** is the value stack. Frame future scoping conversations around the recurring multi-year value, not just the amendment.
- **Tommy is NOT at relationship risk despite IRS balance stress** — financially stressed but operationally engaged, prompt in replies, and actively referring new clients.
- **Execution-speed risk on Accruity side** — failure to convert the planning framework into delivered amendment + dep reclass + cost-seg + S-corp would erode trust over time.
- **Andy-side coverage parallel** — symmetric 50/50 across all entities; Apr 14 thread CC'd only Tommy. When Andy's dossier is generated, run the asymmetric-service-depth check (analog of Spring/Brian).

**New — dossier-generation plumbing items flagged:**
- 11 plumbing items (#9–#16, #19–#22): dual-Account resolution, missing relations, EL origination, Files & Links rows, 5 unlinked workbooks, transcript pulls, Claude Summary structured links, Andy dossier queue, Outlook scan.

### 13.2 Carry-over summary (for next refresh)

| Count | Bucket | Reference |
| --- | --- | --- |
| 22 | Open / In-progress action items | §7.1 |
| 8 | "Gaps to backfill next refresh" items across sections | §3.4 · §4.5 · §5.4 · §6.6 · §7.4 · §8.3 · §9.4 |
| 11 | Strategy lines (some HIGH quantified, several `? Pending workbook`) | §8.1 |
| 4 | HIGH opportunity flags promoted to §7 | §9.1 + §9.2 |
| 13 | Cost Seg Proposal Intake rows awaiting property-data population | §5.2 |
| 5 | Core tax workbooks not linked to Account | §5.4 |
| 1 | Suspected duplicate / wrong Account relation to resolve | §4.2 |

### 13.3 What a reader should look at first on next refresh

1. **§13.1 block dated 2026-04-22** — this baseline. Anything marked "new" here is not in the prior dossier because there isn't one.
2. **§7.1 Action #1** — confirm extension was filed before Apr 15 with payment processed (refresh date Apr 22 is post-deadline).
3. **§9.1 + §9.2** — the $110K/yr ongoing S-corp savings + LHI cost-seg priority. These are the largest value-creation items in the file.
4. **§5.2 / Action #7** — populate the 13 Cost Seg Proposal Intake rows with real property data; everything in §9.1 unlocks once that's done.
5. **§7.1 Action #9 / §4.2 dual-Account flag** — confirm whether `30d49172…7e04` is a duplicate Tommy or Andy's account; data integrity question.

---
*Internal document — not for client distribution.*
*Accruity · www.accruity.com*
*Source: [dossiers/TommyHarr/dossier.md](.) on branch `claude/update-exec-summary-notion-118m7`*
*First generated: 2026-04-22 · Next scheduled refresh: TBD (trigger on email delta or manual)*
